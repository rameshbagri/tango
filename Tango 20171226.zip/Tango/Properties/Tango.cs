﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Tools.Ribbon;

namespace Tango.Properties
{
    public partial class Tango
    {
        private void Tango_Load(object sender, RibbonUIEventArgs e)
        {

        }
    }
}
