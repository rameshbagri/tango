﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Word;
using Microsoft.Office.Tools;
using System.Windows.Forms;


namespace Tango
{
    public partial class TangoUserControl : UserControl
    {

        public TangoUserControl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Panel pnl = new Panel();
            pnl.Name = "TabPnl";
            TabControl TC = new TabControl();
            TC.Name = "TabCtrl";
            this.Controls.Add(pnl);
            pnl.Controls.Add(TC);

            pnl.Height = this.Height - 2;
            pnl.Width = this.Width - 2;
            TC.Height = pnl.Height - 2;
            TC.Width = pnl.Width - 2;

            if (checkBox1.Checked)
            {
                TabPage tp = new TabPage();
                tp.Name = "Page1";
                tp.Text = "Function 1";
                TC.Controls.Add(tp);
                Panel P1 = AddPanel("Page1_0", 0, 0, tp.Width, tp.Height);
                tp.Controls.Add(P1);
                Control B = AddBtn(P1.Height - 20, 5, "btnSearch", "Search Item", btnSearch_Click);
                TextBox TB = new TextBox();
                TB.Name = "txtSearch";
                P1.Controls.Add(TB);
                P1.Controls.Add(B);
            }
            if (checkBox2.Checked)
            {
                TabPage tp2 = new TabPage();
                tp2.Name = "Page2";
                tp2.Text = "Function 2";
                TC.Controls.Add(tp2);
            }
            if (checkBox3.Checked)
            {
                TabPage tp = new TabPage();
                tp.Name = "Page3";
                tp.Text = "Function 3";
                TC.Controls.Add(tp);
            }

            pnlFunctionList.Visible = false;
            pnl.Visible = true;
            pnl.Height = 1000;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Word.Document docs = Globals.ThisAddIn.Application.ActiveDocument;
            Microsoft.Office.Interop.Word.Range rng = docs.Content;
            rng.Find.ClearFormatting();
            object findtext = GetTextVal("txtSearch");
            rng.Find.Forward=true;
            rng.Find.Execute(ref findtext);
            int founCount = 0;
            while(rng.Find.Found)
            {
                rng.Find.Execute(ref findtext);
                founCount++;
            }
            
            Control Ctr = GetCtrl("Page1_0");
            Control L1 = AddLabel(Ctr.Height - 200, 25,founCount);
            
            Ctr.Controls.Add(L1);
            
            Control B1 = AddBtn(Ctr.Height - 20, Ctr.Width - 25, "btnNext", "Next Page", btnNext_Click);
            Ctr.Controls.Add(B1);
            B1.Left = Ctr.Width - B1.Width - 5;
            ////MessageBox.Show(findtext);
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Word.Document docs = Globals.ThisAddIn.Application.ActiveDocument;
            Microsoft.Office.Interop.Word.Range rng = docs.Content;
            rng.Find.ClearFormatting();

            Control Ctr = GetCtrl("Page1");
            Control P = AddPanel("Page1_1", 0, 0, Ctr.Width - 2, Ctr.Height -2);
            Ctr.Controls.Add(P);

            ListBox CL = new ListBox();
            CL.Name = "ListBox1";
            CL.Top = 0;
            CL.Left = 0;
            CL.Height = (int)((double)(P.Height) * 0.8);
            CL.Width = (int)((double)(P.Width) * 0.98);

            ListBox CL1 = new ListBox();
            CL1.Name = "ListBox2";
            CL1.Visible = false;


            int scount = docs.Sentences.Count;
            object findtext = GetTextVal("txtSearch");

            for (int i = 1; i<= scount;i++)
            {
                Microsoft.Office.Interop.Word.Range rng1 = docs.Sentences[i];
                rng1.Find.ClearFormatting();
                rng1.Find.Forward = true;
                rng1.Find.Execute(ref findtext);
                if(rng1.Find.Found)
                {
                    CL.Items.Add(docs.Sentences[i].Text);
                    CL1.Items.Add(i);
                }
            }
            CL.ScrollAlwaysVisible=true;
            CL.HorizontalScrollbar = true;
            //int index = CL.SelectedIndex;
            
            CL.Click += ListBox1_Click;

            Control B1 = AddBtn(CL.Height + 5, 5, "btnSelectAll", "Select All", btnSelectAll_Click);

            P.Controls.Add(CL);
            P.Controls.Add(CL1);
            P.Controls.Add(B1);
            Control Ctr1 = GetCtrl("Page1_0");
            Ctr1.Visible = false;
            P.Visible = true;
        }

        private void ListBox1_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Word.Document docs = Globals.ThisAddIn.Application.ActiveDocument;
            Control CLB = GetCtrl("ListBox1") as ListBox;
            Control LB = GetCtrl("ListBox2") as ListBox;
            string s = CLB.Text;
            int index = (GetCtrl("ListBox1") as ListBox).SelectedIndex;
 
            string strIndex = (GetCtrl("ListBox2") as ListBox).Items[index].ToString();
            int index1 = int.Parse(strIndex);
            Microsoft.Office.Interop.Word.Range rng1 = docs.Sentences[index1];
            rng1.Select();
            
        }

        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            Control C = GetCtrl("CheckedListBox1");
            
            foreach(CheckBox item in C.Controls)
            {
                item.Checked = true;
            }
        }

        private string SearchSentence(int s, int e, string str)
        {
            string Stxt = "null";

            return Stxt;
        }

        private Panel AddPanel(string name,int top, int left, int wid, int H)
        {
            Panel pnl = new Panel();
            pnl.Name = name;
            pnl.Top = top;
            pnl.Left = left;
            pnl.Width = wid;
            pnl.Height = H;
            return pnl;
        }

        private Control AddLabel(int Top, int Left, int founCount)
        {
            Label lb = new Label();
            lb.Text = "Count : " + founCount.ToString();
            lb.Top = Top;
            lb.Left = Left;
            return lb;
        }

        private Control AddTextBox(int Top, int Left, string name, string val)
        {
            TextBox T = new TextBox();
            T.Name = name;
            T.Top = Top;
            T.Left = Left;
            if (!val.Equals("")) { T.Text = val; }
            return T;
        }

        private Control AddBtn(int top, int left, string name, string caption, EventHandler clickevent)
        {
            Button B = new Button();
            B.Name = name;
            B.Top = top;
            B.Left = left;
            B.Text = caption;
            B.Click += clickevent;
            return B;
        }

        private Control AddListBox(int top, int left, string name)
        {
            ListBox L = new ListBox();
            L.Name = name;
            L.Top = top;
            L.Left = left;
            
            return L;
        }

        public string GetTextVal(string cName)
        {
            string findtext = "";
            foreach (Control c in this.Controls)
            {
                if (c is TextBox)
                {
                    var tnm = c.Name;
                    if (tnm == cName)
                    {
                        findtext = c.Text;
                        //MessageBox.Show(findtext);
                    }
                }
                else
                {
                    foreach (Control c1 in c.Controls)
                    {
                        if (c1 is TextBox)
                        {
                            var tnm = c1.Name;
                            if (tnm == cName)
                            {
                                findtext = c1.Text;
                                //MessageBox.Show(findtext);
                            }
                        }
                        else
                        {
                            foreach (Control c2 in c1.Controls)
                            {
                                if (c2 is TextBox)
                                {
                                    var tnm = c2.Name;
                                    if (tnm == cName)
                                    {
                                        findtext = c2.Text;
                                        //MessageBox.Show(findtext);
                                    }
                                }
                                else
                                {
                                    foreach (Control c3 in c2.Controls)
                                    {
                                        if (c3 is TextBox)
                                        {
                                            var tnm = c3.Name;
                                            if (tnm == cName)
                                            {
                                                findtext = c3.Text;
                                                //MessageBox.Show(findtext);
                                            }
                                        }
                                        else
                                        {
                                            foreach (Control c4 in c3.Controls)
                                            {
                                                if (c4 is TextBox)
                                                {
                                                    var tnm = c4.Name;
                                                    if (tnm == cName)
                                                    {
                                                        findtext = c4.Text;
                                                        //MessageBox.Show(findtext);
                                                    }
                                                }
                                                else
                                                {
                                                    foreach (Control c5 in c4.Controls)
                                                    {
                                                        if (c5 is TextBox)
                                                        {
                                                            var tnm = c5.Name;
                                                            if (tnm == cName)
                                                            {
                                                                findtext = c5.Text;
                                                                //MessageBox.Show(findtext);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return findtext;
        }

        public Control GetCtrl(string cName)
        {
            Control findtext = new Control();
            foreach (Control c in this.Controls)
            {
                var tnm = c.Name;
                if (tnm == cName)
                {
                    findtext = c;
                }
                else
                {
                    foreach (Control c1 in c.Controls)
                    {
                        tnm = c1.Name;
                        if (tnm == cName)
                        {
                            findtext = c1;
                        }
                        else
                        {
                            foreach (Control c2 in c1.Controls)
                            {
                                tnm = c2.Name;
                                if (tnm == cName)
                                {
                                    findtext = c2;
                                    //MessageBox.Show(findtext);
                                }
                                else
                                {
                                    foreach (Control c3 in c2.Controls)
                                    {
                                        tnm = c3.Name;
                                        if (tnm == cName)
                                        {
                                            findtext = c3;
                                            //MessageBox.Show(findtext);
                                        }
                                        else
                                        {
                                            foreach (Control c4 in c3.Controls)
                                            {
                                                tnm = c4.Name;
                                                if (tnm == cName)
                                                {
                                                    findtext = c4;
                                                    //MessageBox.Show(findtext);
                                                }
                                                else
                                                {
                                                    foreach (Control c5 in c4.Controls)
                                                    {
                                                        tnm = c5.Name;
                                                        if (tnm == cName)
                                                        {
                                                            findtext = c5;
                                                            //MessageBox.Show(findtext);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return findtext;
        }

    }
}
